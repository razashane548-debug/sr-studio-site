// Download proxy: serves app release files at site-domain paths.
// The upstream store URL lives only here, server-side; it never appears
// in any public HTML, response header, or redirect chain.
const FILES = {
  "reshu/Reshu-PDF-Reader-v0.3.5.apk": {
    url: "https://github.com/razashane548-debug/srq-builds/releases/download/reshu-v0.3.5/Reshu-PDF-Reader-v0.3.5.apk",
    type: "application/vnd.android.package-archive",
    name: "Reshu-PDF-Reader-v0.3.5.apk",
  },
};

const INDEX_HTML = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/><meta content="width=device-width,initial-scale=1" name="viewport"/><title>Downloads | SR Studio</title><link href="/favicon.svg" rel="icon"/><link href="/style.css?v=5" rel="stylesheet"/><meta content="noindex" name="robots"/></head><body><a class="skip-link" href="#main">Skip to main content</a><header class="site-header"><div class="wrap header-inner"><a class="brand" href="/"><span aria-hidden="true" class="brand-mark">SR</span><span>SR Studio</span></a><nav aria-label="Main navigation"><a href="/">Home</a><a href="/apps/">Apps</a><a href="/articles/">Articles</a><a href="/#contact">Contact</a></nav></div></header><main class="wrap section prose" id="main" tabindex="-1"><h1>Downloads</h1><p>Official SR Studio app downloads, served directly from this website.</p><h2>Reshu PDF Reader</h2><p><a class="button primary" href="/download/reshu/Reshu-PDF-Reader-v0.3.5.apk">Download Reshu 0.3.5 APK</a></p><p>Android 6.0 or newer. Free and ad-free pre-release. Check <a href="/apps/reshu/">the Reshu page</a> for requirements, known limits and privacy information before installing.</p></main><footer class="site-footer"><div class="wrap footer-inner"><span>&copy; 2026 SR Studio. All rights reserved.</span><a href="/about/">About</a><a href="/support/">Support &amp; FAQ</a></div></footer></body></html>`;

function notFound() {
  return new Response("Not found. See https://srstudio.dpdns.org/download/ for available downloads.\n", {
    status: 404,
    headers: { "content-type": "text/plain; charset=utf-8", "x-content-type-options": "nosniff" },
  });
}

export async function onRequest(context) {
  const parts = context.params.path || [];
  const key = parts.join("/");

  if (key === "") {
    return new Response(INDEX_HTML, {
      headers: { "content-type": "text/html; charset=utf-8", "x-content-type-options": "nosniff" },
    });
  }

  const file = FILES[key];
  if (!file) return notFound();

  const method = context.request.method;
  if (method !== "GET" && method !== "HEAD") {
    return new Response("Method not allowed.\n", { status: 405, headers: { "allow": "GET, HEAD" } });
  }

  const reqHeaders = new Headers();
  const range = context.request.headers.get("range");
  if (range) reqHeaders.set("range", range);

  let upstream;
  try {
    upstream = await fetch(file.url, { method, headers: reqHeaders, redirect: "follow" });
  } catch (e) {
    return new Response("Download temporarily unavailable. Please try again later.\n", { status: 502 });
  }
  if (!upstream.ok && upstream.status !== 206) {
    return new Response("Download temporarily unavailable. Please try again later.\n", { status: 502 });
  }

  // Forward only the file bytes and download-safe headers; every upstream
  // header (which could name the store) is dropped.
  const headers = new Headers();
  headers.set("content-type", file.type);
  headers.set("content-disposition", `attachment; filename="${file.name}"`);
  headers.set("cache-control", "public, max-age=3600");
  headers.set("x-content-type-options", "nosniff");
  for (const h of ["content-length", "content-range", "accept-ranges", "etag", "last-modified"]) {
    const v = upstream.headers.get(h);
    if (v) headers.set(h, v);
  }

  return new Response(upstream.body, { status: upstream.status, headers });
}
